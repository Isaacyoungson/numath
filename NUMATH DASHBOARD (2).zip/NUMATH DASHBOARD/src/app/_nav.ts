import { INavData } from '@coreui/angular';

export const navItems: INavData[] = [
  {
    name: 'Dashboard',
    url: '/dashboard',
    icon: 'icon-speedometer',
  },
  {
    divider: true
  },
      {
        name: 'User\'s Profile',
        url: '/userInfo/userprofile',
        icon: 'icon-user'
      },
      {
        divider: true
      },
      {
        name: 'Users List',
        url: '/userInfo/userlist',
        icon: 'icon-list'
      },
      {
        divider: true
      },
      {
        name: 'Register',
        url: '/userInfo/register',
        icon: 'icon-lock'
      },
      {
        divider: true
      },
      {
        name: 'Notifications',
        url: '/notifications/alerts',
        icon: 'icon-bell',
        badge: {
          variant: 'info',
          text: 'NEW'
        }
      },
  {
    divider: true
  },
      {
        name: 'Login',
        url: '/login',
        icon: 'icon-login'
      },

];
