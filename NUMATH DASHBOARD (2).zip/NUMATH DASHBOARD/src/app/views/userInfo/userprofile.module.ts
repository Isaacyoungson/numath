import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';

import { UserProfileComponent } from './userprofile.component';
import { RegisterComponent } from './register.component';

// Dropdowns Component
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { UserListComponent } from './userlist.component';

// Buttons Routing
import { ButtonsRoutingModule } from './userprofile-routing.module';

// Angular

@NgModule({
  imports: [
    CommonModule,
    ButtonsRoutingModule,
    BsDropdownModule.forRoot(),
    FormsModule
  ],
  declarations: [
    UserProfileComponent,
    UserListComponent,
    RegisterComponent
  ]
})
export class ButtonsModule { }
