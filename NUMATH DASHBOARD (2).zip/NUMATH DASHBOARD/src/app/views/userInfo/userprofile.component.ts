import { Component } from '@angular/core';

@Component({
  templateUrl: 'userprofile.component.html'
})
export class UserProfileComponent {

  constructor() { }

}
