import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UserProfileComponent } from './userprofile.component';
import { UserListComponent } from './userlist.component';
import { RegisterComponent } from './register.component';

const routes: Routes = [
  {
    path: '',
    data: {
      title: 'UserInfo'
    },
    children: [
      {
        path: '',
        redirectTo: 'userInfo'
      },
      {
        path: 'userprofile',
        component: UserProfileComponent,
        data: {
          title: 'userprofile'
        }
      },
      {
        path: 'userlist',
        component: UserListComponent,
        data: {
          title: 'userlist'
        }
      },
      {
        path: 'register',
        component: RegisterComponent,
        data: {
          title: 'register'
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ButtonsRoutingModule {}
